const researchers = [
    {
        name: "Chris Brackley",
        homepage: "https://sites.google.com/site/cabrackley",
        expertise: "Theoretical physicist at SoPA, with expertise in theory and simulations of chromatin organisation at the nucleosome and whole-chromosome scale",
        interests: "3D chromatin structure in health and disease, chromatin remodelling in cancer, DNA and chromatin supercoiling in health and disease"
    },
    {
        name: "Gerry Brien",
        homepage: "https://www.ed.ac.uk/cancer-centre/research/brien-group",
        expertise: "Chromatin biochemist at the IGC, Cancer Research UK Scotland, with expertise in cancer epigenetics",
        interests: "Mechanisms of epigenetic disregulation in cancer, biochemistry of chromatin regulation, development of new cancer therapeutics"
    },
    {
        name: "Nick Gilbert",
        homepage: "https://www.chromatinlab.org",
        expertise: "Chromatin biologist at the IGC, with expertise in optical and super-resolution microscopy, cell biology assays, next-generation sequencing",
        interests: "3D structure of chromatin and chromosomes, transcription in health and disease, chromatin topology in health and disease, common fragile sites, chromatin supercoiling, single-cell RNA-seq"
    },
    {
        name: "Ava Khamseh",
        homepage: "https://edbiomed.ai",
        expertise: "Computational biologist at the IGC and Informatics, with expertise in machine learning, statistical analysis and statistical modelling",
        interests: "Genetics and transcriptomics in cancer, machine learning for large-scale biomedical data, mechanistic models for oncogenesis"
    },
    {
        name: "Davide Marenduzzo",
        homepage: "https://www2.ph.ed.ac.uk/~dmarendu",
        expertise: "Theoretical physicist at SoPA, with expertise in polymer models, coarse-grained molecular dynamics simulations, statistical models",
        interests: "3D structure of chromatin and chromosomes, transcription in health and disease, chromatin topology in health and disease"
    },
    {
        name: "Giuseppe Negro",
        homepage: "https://it.linkedin.com/in/giuseppe-negro-698502121",
        expertise: "Computational physicist at SoPA, with expertise in large-scale computer simulations of biological and soft matter physics",
        interests: "RNA/protein gels inside the nucleus, phase field modelling for chromatin, modelling of nuclear structures in eukaryotes"
    },
    {
        name: "Willem Vanderlinden",
        homepage: "https://www.ph.ed.ac.uk/people/willem-vanderlinden",
        expertise: "Biophysicist at SoPA, with expertise in atomic force microscopy and single molecule experiments",
        interests: "3D structure of chromatin and chromosomes, chromatin-binding proteins, DNA and chromatin topology"
    }
];

const PhDStudents = [
    // Add names here if available in the future
];

export const MMD = {
    title: "Molecular mechanisms of disease",
    subtitle: "Research",
    description: 'This research area investigates the molecular and cellular mechanisms underlying various diseases to develop new therapeutic strategies.'
    ,
    background: 'bg-gradient-to-r from-green-900 via-teal-700 to-blue-500',
    bannerImages: [
        {
            src: "HiPHoP.jpg",
            alt: "HiP-HoP",
            width: 400,
            height: 400
        },
        {
            src: "SAMD4A.jpg",
            alt: "SAMD4A",
            width: 500,
            height: 400
        },
        {caption: "(Left) Sketch of the HiP-HoP model, developed by the Gilbert and Marenduzzo groups to predict chromatin structure genome-wide in human cells. (Right) Example of HiP-HoP simulation for SAMD4A, a key gene in inflammatory response. Click here to access 3DGene, which contains HiP-HoP results for 3D genome structure genome-wide.",}

],

    researchers: researchers,
    phdStudents: PhDStudents,

};

// legend: {
//     sopa: "School of Physics and Astronomy",
//         igc: "Institute for Genetics and Cancer",
//         sbs: "School of Biological Sciences",
//         ecbp: "Edinburgh Centre for Biomedical Physics",
//         hipHop: "highly predictive heteromorphic polymer model"
// },
// lastUpdated: "04/09/2024"
