export const events = [
    {
        title: 'Physics of Viruses meeting',
        description: 'Upcoming Event',
        background: 'bg-gradient-to-r from-yellow-900 via-orange-700 to-red-600',

    }
]